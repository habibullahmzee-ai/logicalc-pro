import { GoogleGenAI } from "@google/genai";

// Fix: Always use new GoogleGenAI({apiKey: process.env.API_KEY}) directly per guidelines
const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export const explainMathExpression = async (expression: string, result: string): Promise<string> => {
  if (!process.env.API_KEY) {
    return "API Key not configured. Please check your settings.";
  }

  try {
    const prompt = `
      You are a helpful math tutor. The user has calculated the following expression:
      Expression: ${expression}
      Result: ${result}

      Please provide a brief, step-by-step explanation of how this result was achieved. 
      If it involves Logarithms or Anti-Logarithms, explain the base used clearly.
      Keep the explanation concise and easy to understand.
      Format the output with Markdown.
    `;

    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: prompt,
    });

    return response.text || "Could not generate explanation.";
  } catch (error) {
    console.error("Gemini API Error:", error);
    return "Sorry, I couldn't explain this calculation right now.";
  }
};

export const solveMathImage = async (base64Image: string, mimeType: string): Promise<string> => {
  if (!process.env.API_KEY) {
    return "API Key not configured.";
  }

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: {
        parts: [
          {
            inlineData: {
              mimeType: mimeType,
              data: base64Image
            }
          },
          {
            text: "Analyze this image. If it contains a math problem, solve it step-by-step and explain the solution clearly. Use Markdown for formatting math symbols."
          }
        ]
      }
    });

    return response.text || "Could not analyze the image.";
  } catch (error) {
    console.error("Gemini Image API Error:", error);
    return "Sorry, I couldn't solve the problem in this image.";
  }
};