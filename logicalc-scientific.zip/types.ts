export interface HistoryItem {
  expression: string;
  result: string;
  timestamp: number;
}

export enum ButtonType {
  NUMBER = 'NUMBER',
  OPERATOR = 'OPERATOR',
  ACTION = 'ACTION',
  SCIENTIFIC = 'SCIENTIFIC',
  SPECIAL = 'SPECIAL'
}

export interface CalcButton {
  label: string;
  value: string;
  type: ButtonType;
  className?: string;
  tooltip?: string;
}