import React, { useState, useEffect } from 'react';
import Calculator from './components/Calculator';

function App() {
  const [installPrompt, setInstallPrompt] = useState<any>(null);
  const [isStandalone, setIsStandalone] = useState(false);
  const [isOnline, setIsOnline] = useState(navigator.onLine);

  useEffect(() => {
    // Check if running in standalone mode (installed like an app)
    const checkStandalone = () => {
      const isStandaloneMode = window.matchMedia('(display-mode: standalone)').matches || 
                               (window.navigator as any).standalone;
      setIsStandalone(!!isStandaloneMode);
    };
    
    checkStandalone();
    window.matchMedia('(display-mode: standalone)').addEventListener('change', checkStandalone);

    // Network status listeners
    const handleOnline = () => setIsOnline(true);
    const handleOffline = () => setIsOnline(false);

    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);

    // Install prompt handler
    const handler = (e: any) => {
      e.preventDefault();
      setInstallPrompt(e);
    };

    window.addEventListener('beforeinstallprompt', handler);

    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
      window.removeEventListener('beforeinstallprompt', handler);
    };
  }, []);

  const handleInstallClick = async () => {
    if (!installPrompt) return;
    installPrompt.prompt();
    const { outcome } = await installPrompt.userChoice;
    if (outcome === 'accepted') {
      setInstallPrompt(null);
    }
  };

  return (
    <div className="min-h-screen bg-slate-950 flex flex-col items-center justify-center p-4 relative overflow-hidden">
      
      {/* Background Decor */}
      <div className="absolute top-[-20%] left-[-20%] w-[50%] h-[50%] bg-indigo-900/20 blur-[100px] rounded-full pointer-events-none"></div>
      <div className="absolute bottom-[-20%] right-[-20%] w-[50%] h-[50%] bg-emerald-900/20 blur-[100px] rounded-full pointer-events-none"></div>

      {/* Offline Banner */}
      {!isOnline && (
        <div className="fixed top-0 left-0 right-0 bg-red-900/90 text-red-100 text-xs font-medium text-center py-2 z-50 backdrop-blur-sm border-b border-red-500/30">
          No Internet Connection. AI features are disabled.
        </div>
      )}

      {/* Header - Hidden if installed (Standalone) to save space */}
      {!isStandalone && (
        <header className="mb-6 text-center w-full max-w-sm flex flex-col items-center z-10">
          <h1 className="text-3xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-indigo-400 to-emerald-400 mb-2">
            LogiCalc Pro
          </h1>
          <p className="text-slate-400 text-sm mb-4">
            Scientific Calculator with Log, Anti-Log & AI
          </p>
          
          {installPrompt && (
            <button
              onClick={handleInstallClick}
              className="flex items-center gap-2 px-4 py-2 rounded-full bg-slate-900 border border-emerald-500/30 text-emerald-400 text-sm font-medium hover:bg-emerald-900/20 transition-all animate-bounce shadow-lg shadow-emerald-900/20"
            >
              <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/></svg>
              Install App
            </button>
          )}
        </header>
      )}

      <main className="w-full z-10 flex-1 flex flex-col justify-center">
        <Calculator />
      </main>

      {!isStandalone && (
        <footer className="mt-8 text-center text-slate-600 text-xs z-10">
          <p>Powered by Gemini AI</p>
        </footer>
      )}
    </div>
  );
}

export default App;