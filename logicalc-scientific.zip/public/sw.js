const CACHE_NAME = 'logicalc-offline-v3';

// Core files to pre-cache immediately
const PRE_CACHE_URLS = [
  '/',
  '/index.html',
  '/manifest.json'
];

// Domains that should be cached dynamically (Tailwind, React, Fonts, Icons)
const CACHE_DOMAINS = [
  'cdn.tailwindcss.com',
  'esm.sh',
  'fonts.googleapis.com',
  'fonts.gstatic.com',
  'cdn-icons-png.flaticon.com'
];

self.addEventListener('install', (event) => {
  self.skipWaiting(); // Force activation
  event.waitUntil(
    caches.open(CACHE_NAME)
      .then((cache) => cache.addAll(PRE_CACHE_URLS))
  );
});

self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches.keys().then((cacheNames) => {
      return Promise.all(
        cacheNames.map((cacheName) => {
          if (cacheName !== CACHE_NAME) {
            return caches.delete(cacheName);
          }
        })
      );
    })
  );
});

self.addEventListener('fetch', (event) => {
  const url = new URL(event.request.url);

  // 1. NETWORK ONLY: Do not cache Gemini API calls
  if (url.hostname.includes('generativelanguage.googleapis.com')) {
    return; // Standard network fetch
  }

  // 2. CACHE FIRST / STALE-WHILE-REVALIDATE for Assets
  // Check if request is for our app or allowed external domains
  const isExternalAsset = CACHE_DOMAINS.some(domain => url.hostname.includes(domain));
  const isLocalAsset = url.origin === self.location.origin;

  if (isLocalAsset || isExternalAsset) {
    event.respondWith(
      caches.match(event.request).then((cachedResponse) => {
        if (cachedResponse) {
          return cachedResponse;
        }
        return fetch(event.request).then((networkResponse) => {
          if (!networkResponse || networkResponse.status !== 200 || networkResponse.type !== 'basic' && networkResponse.type !== 'cors') {
            return networkResponse;
          }
          const responseToCache = networkResponse.clone();
          caches.open(CACHE_NAME).then((cache) => {
            cache.put(event.request, responseToCache);
          });
          return networkResponse;
        }).catch(() => {});
      })
    );
  }
});