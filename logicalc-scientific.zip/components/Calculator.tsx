import React, { useState, useCallback, useRef } from 'react';
import { ButtonType, CalcButton, HistoryItem } from '../types';
import Display from './Display';
import HistoryPanel from './HistoryPanel';
import { explainMathExpression, solveMathImage } from '../services/geminiService';

const BUTTONS: CalcButton[] = [
  // Row 1: Advanced Log/Exp
  { label: 'log₁₀', value: 'log(', type: ButtonType.SCIENTIFIC, tooltip: 'Log base 10' },
  { label: '10ˣ', value: '10^', type: ButtonType.SCIENTIFIC, tooltip: 'Anti-Log (Base 10)' },
  { label: 'ln', value: 'ln(', type: ButtonType.SCIENTIFIC, tooltip: 'Natural Log' },
  { label: 'eˣ', value: 'e^', type: ButtonType.SCIENTIFIC, tooltip: 'Anti-Ln (Exponential)' },
  
  // Row 2: Basic Sci
  { label: 'x²', value: '^2', type: ButtonType.SCIENTIFIC },
  { label: '√', value: '√(', type: ButtonType.SCIENTIFIC },
  { label: '(', value: '(', type: ButtonType.SCIENTIFIC },
  { label: ')', value: ')', type: ButtonType.SCIENTIFIC },
  
  // Row 3: Clear/Ops
  { label: 'AC', value: 'AC', type: ButtonType.ACTION, className: 'text-red-400' },
  { label: 'DEL', value: 'DEL', type: ButtonType.ACTION },
  { label: '%', value: '%', type: ButtonType.OPERATOR },
  { label: '÷', value: '/', type: ButtonType.OPERATOR },
  
  // Row 4
  { label: '7', value: '7', type: ButtonType.NUMBER },
  { label: '8', value: '8', type: ButtonType.NUMBER },
  { label: '9', value: '9', type: ButtonType.NUMBER },
  { label: '×', value: '*', type: ButtonType.OPERATOR },
  
  // Row 5
  { label: '4', value: '4', type: ButtonType.NUMBER },
  { label: '5', value: '5', type: ButtonType.NUMBER },
  { label: '6', value: '6', type: ButtonType.NUMBER },
  { label: '-', value: '-', type: ButtonType.OPERATOR },
  
  // Row 6
  { label: '1', value: '1', type: ButtonType.NUMBER },
  { label: '2', value: '2', type: ButtonType.NUMBER },
  { label: '3', value: '3', type: ButtonType.NUMBER },
  { label: '+', value: '+', type: ButtonType.OPERATOR },
  
  // Row 7
  { label: '0', value: '0', type: ButtonType.NUMBER, className: 'col-span-2 w-full text-left pl-6 bg-slate-800 text-white hover:bg-slate-700' },
  { label: '.', value: '.', type: ButtonType.NUMBER },
  { label: '=', value: '=', type: ButtonType.SPECIAL, className: 'bg-indigo-600 text-white shadow-lg shadow-indigo-500/50' },
];

const Calculator: React.FC = () => {
  const [input, setInput] = useState<string>('');
  const [result, setResult] = useState<string>('');
  const [history, setHistory] = useState<HistoryItem[]>([]);
  const [showHistory, setShowHistory] = useState<boolean>(false);
  const [explanation, setExplanation] = useState<string | null>(null);
  const [isLoadingAI, setIsLoadingAI] = useState(false);
  
  const fileInputRef = useRef<HTMLInputElement>(null);

  const safeEvaluate = (expression: string): string => {
    try {
      // Create a sanitized string for evaluation
      let evalStr = expression
        .replace(/×/g, '*')
        .replace(/÷/g, '/')
        .replace(/log\(/g, 'Math.log10(')
        .replace(/ln\(/g, 'Math.log(')
        .replace(/√\(/g, 'Math.sqrt(')
        .replace(/π/g, 'Math.PI')
        .replace(/e/g, 'Math.E')
        .replace(/\^/g, '**');

      // eslint-disable-next-line no-new-func
      const func = new Function(`return ${evalStr}`);
      const val = func();
      
      if (!isFinite(val) || isNaN(val)) return 'Error';
      
      const stringVal = val.toString();
      if (stringVal.length > 10) {
        return val.toPrecision(8).replace(/\.?0+$/, ''); 
      }
      return stringVal;
    } catch (e) {
      return 'Error';
    }
  };

  const handlePress = useCallback((btn: CalcButton) => {
    setExplanation(null); // Clear AI explanation on new input

    if (btn.value === 'AC') {
      setInput('');
      setResult('');
      return;
    }

    if (btn.value === 'DEL') {
      setInput((prev) => prev.slice(0, -1));
      return;
    }

    if (btn.value === '=') {
      if (!input) return;
      const res = safeEvaluate(input);
      setResult(res);
      setHistory((prev) => [
        { expression: input, result: res, timestamp: Date.now() },
        ...prev.slice(0, 9) // Keep last 10
      ]);
      return;
    }

    const isOperator = ['+', '-', '*', '/', '%', '^'].includes(btn.value);
    if (isOperator && input === '') return;
    if (isOperator && ['+', '-', '*', '/', '%', '^'].includes(input.slice(-1))) {
      setInput((prev) => prev.slice(0, -1) + btn.value);
      return;
    }

    setInput((prev) => prev + btn.value);
  }, [input]);

  const handleAIExplain = async () => {
    if (!input || !result) return;
    if (!navigator.onLine) {
        setExplanation("# Offline\nYou are currently offline. Please connect to the internet to use AI features.");
        return;
    }

    setIsLoadingAI(true);
    setExplanation("Analyzing with Gemini AI...");
    const explanationText = await explainMathExpression(input, result);
    setExplanation(explanationText);
    setIsLoadingAI(false);
  };

  const handleCameraClick = () => {
    if (!navigator.onLine) {
        // We can show the modal immediately for the error
        setExplanation("# Offline\nInternet connection is required to process images with AI.");
        return;
    }
    fileInputRef.current?.click();
  };

  const handleFileChange = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    if (!navigator.onLine) {
        setExplanation("# Offline\nInternet connection is required to solve images.");
        event.target.value = ''; // reset
        return;
    }

    setIsLoadingAI(true);
    setExplanation("Scanning image and solving problem..."); // Show loading in modal

    // Convert to base64
    const reader = new FileReader();
    reader.onloadend = async () => {
      const base64String = reader.result as string;
      const base64Data = base64String.split(',')[1];
      const mimeType = file.type;

      const solution = await solveMathImage(base64Data, mimeType);
      setExplanation(solution);
      setIsLoadingAI(false);
    };
    reader.readAsDataURL(file);
    
    // Reset input so same file can be selected again
    event.target.value = '';
  };

  return (
    <div className="relative w-full max-w-sm mx-auto bg-slate-800 rounded-3xl shadow-2xl overflow-hidden border border-slate-700">
      
      {/* Hidden File Input */}
      <input 
        type="file" 
        ref={fileInputRef}
        accept="image/*"
        className="hidden"
        onChange={handleFileChange}
      />

      <Display 
        input={input} 
        result={result} 
        history={history} 
        showHistory={showHistory}
        toggleHistory={() => setShowHistory(!showHistory)}
        onCameraTap={handleCameraClick}
      />

      <HistoryPanel 
        history={history} 
        isOpen={showHistory} 
        onSelect={(item) => {
          setInput(item.expression);
          setResult(item.result);
          setShowHistory(false);
        }}
        onClear={() => setHistory([])}
      />

      <div className="p-4 grid grid-cols-4 gap-3 bg-slate-900/50">
        {BUTTONS.map((btn, idx) => (
          <button
            key={idx}
            onClick={() => handlePress(btn)}
            className={`
              h-16 rounded-2xl flex items-center justify-center text-xl font-medium transition-all duration-150 active:scale-95
              ${btn.className || ''}
              ${btn.type === ButtonType.NUMBER && !btn.className ? 'bg-slate-800 text-white hover:bg-slate-700' : ''}
              ${btn.type === ButtonType.OPERATOR ? 'bg-indigo-900/40 text-indigo-400 hover:bg-indigo-900/60' : ''}
              ${btn.type === ButtonType.SCIENTIFIC ? 'bg-slate-800 text-emerald-400 text-lg hover:bg-slate-700' : ''}
              ${btn.type === ButtonType.ACTION && !btn.className ? 'bg-slate-800 text-slate-400 hover:bg-slate-700' : ''}
            `}
            title={btn.tooltip}
          >
            {btn.label}
          </button>
        ))}
      </div>

      {/* AI Explain Button (Text) */}
      {result && result !== 'Error' && (
        <div className="px-4 pb-4 bg-slate-900/50">
           <button
             onClick={handleAIExplain}
             disabled={isLoadingAI}
             className="w-full py-3 rounded-xl bg-gradient-to-r from-teal-600 to-emerald-600 text-white font-medium shadow-lg hover:shadow-teal-500/20 transition-all flex items-center justify-center gap-2"
           >
             {isLoadingAI ? (
               <>
                <svg className="animate-spin h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                  <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                  <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                </svg>
                Processing...
               </>
             ) : (
               <>
                 <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/></svg>
                 Ask AI to Explain
               </>
             )}
           </button>
        </div>
      )}

      {/* Full Screen Explanation/Solution Popup */}
      {explanation && (
        <div className="fixed inset-0 z-50 bg-slate-950/95 backdrop-blur-md flex flex-col animate-fade-in">
          <div className="p-4 border-b border-slate-700 flex justify-between items-center bg-slate-900 shadow-xl">
             <h3 className="text-emerald-400 font-bold text-lg flex items-center gap-2">
               <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M2 3h6a4 4 0 0 1 4 4v14a3 3 0 0 0-3-3H2z"></path><path d="M22 3h-6a4 4 0 0 0-4 4v14a3 3 0 0 1 3-3h7z"></path></svg>
               AI Tutor Solution
             </h3>
             <button 
                onClick={() => setExplanation(null)} 
                className="p-2 rounded-full bg-slate-800 text-slate-300 hover:bg-slate-700 hover:text-white transition-colors"
             >
               <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><line x1="18" y1="6" x2="6" y2="18"></line><line x1="6" y1="6" x2="18" y2="18"></line></svg>
             </button>
          </div>
          
          <div className="flex-1 overflow-y-auto p-6 md:p-8">
            <div className="max-w-3xl mx-auto">
                {isLoadingAI ? (
                    <div className="flex flex-col items-center justify-center h-full pt-20">
                        <div className="animate-spin rounded-full h-16 w-16 border-t-2 border-b-2 border-emerald-500 mb-4"></div>
                        <p className="text-emerald-400 text-lg animate-pulse">{explanation}</p>
                    </div>
                ) : (
                    <div className="prose prose-invert prose-emerald max-w-none">
                        <div className="whitespace-pre-wrap text-slate-200 text-base md:text-lg leading-relaxed">
                            {explanation}
                        </div>
                    </div>
                )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default Calculator;