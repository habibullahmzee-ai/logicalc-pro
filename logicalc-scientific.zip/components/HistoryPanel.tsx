import React from 'react';
import { HistoryItem } from '../types';

interface HistoryPanelProps {
  history: HistoryItem[];
  isOpen: boolean;
  onSelect: (item: HistoryItem) => void;
  onClear: () => void;
}

const HistoryPanel: React.FC<HistoryPanelProps> = ({ history, isOpen, onSelect, onClear }) => {
  if (!isOpen) return null;

  return (
    <div className="absolute top-[12rem] left-0 right-0 bottom-0 bg-slate-900/95 backdrop-blur-sm z-20 rounded-b-3xl border-t border-slate-700 flex flex-col transition-all duration-300">
      <div className="p-4 flex justify-between items-center border-b border-slate-700">
        <h3 className="text-slate-300 font-medium">History</h3>
        <button 
          onClick={onClear}
          className="text-xs text-red-400 hover:text-red-300 px-2 py-1 rounded border border-red-900/50 bg-red-900/20"
        >
          Clear All
        </button>
      </div>
      <div className="flex-1 overflow-y-auto p-4 space-y-3">
        {history.length === 0 ? (
          <div className="text-center text-slate-500 mt-10">No history yet</div>
        ) : (
          history.map((item, index) => (
            <button
              key={item.timestamp}
              onClick={() => onSelect(item)}
              className="w-full text-right p-3 rounded-xl bg-slate-800 hover:bg-slate-700 transition-colors group border border-slate-700/50"
            >
              <div className="text-slate-400 text-xs display-font mb-1 group-hover:text-indigo-300">{item.expression}</div>
              <div className="text-white text-lg font-medium display-font">{item.result}</div>
            </button>
          ))
        )}
      </div>
    </div>
  );
};

export default HistoryPanel;