import React, { useEffect, useRef } from 'react';
import { HistoryItem } from '../types';

interface DisplayProps {
  input: string;
  result: string;
  history: HistoryItem[];
  showHistory: boolean;
  toggleHistory: () => void;
  onCameraTap: () => void;
}

const Display: React.FC<DisplayProps> = ({ input, result, history, showHistory, toggleHistory, onCameraTap }) => {
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollLeft = scrollRef.current.scrollWidth;
    }
  }, [input, result]);

  return (
    <div className="relative bg-slate-900 p-6 rounded-t-3xl border-b border-slate-700 h-48 flex flex-col justify-end shadow-inner">
      {/* Top Bar Controls */}
      <div className="absolute top-4 left-0 right-0 px-4 flex justify-between items-center z-10">
        <button 
          onClick={onCameraTap}
          className="p-2 rounded-full text-emerald-400 hover:bg-slate-800 hover:text-emerald-300 transition-colors"
          title="Upload Math Problem"
        >
          <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
            <path d="M23 19a2 2 0 0 1-2 2H3a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h4l2-3h6l2 3h4a2 2 0 0 1 2 2z"></path>
            <circle cx="12" cy="13" r="4"></circle>
          </svg>
        </button>

        <button 
          onClick={toggleHistory}
          className={`p-2 rounded-full transition-colors ${showHistory ? 'bg-indigo-600 text-white' : 'text-slate-400 hover:bg-slate-800'}`}
          title="History"
        >
          <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
            <path d="M3 3v5h5"/><path d="M3.05 13A9 9 0 1 0 6 5.3L3 8"/>
          </svg>
        </button>
      </div>

      <div className="text-right space-y-2 overflow-hidden mt-6">
        <div className="text-slate-400 text-sm h-6">
          {history.length > 0 ? `Prev: ${history[0].result}` : ''}
        </div>
        <div 
          ref={scrollRef}
          className="display-font text-slate-300 text-2xl overflow-x-auto whitespace-nowrap scrollbar-hide opacity-80"
        >
          {input || '0'}
        </div>
        <div className="display-font text-white text-5xl font-bold truncate tracking-wider text-shadow-glow">
          {result || '0'}
        </div>
      </div>
    </div>
  );
};

export default Display;